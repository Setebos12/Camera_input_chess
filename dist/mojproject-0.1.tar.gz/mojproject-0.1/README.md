# Camera_input_chess
